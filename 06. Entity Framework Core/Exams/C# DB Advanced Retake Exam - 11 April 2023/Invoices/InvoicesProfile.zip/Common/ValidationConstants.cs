﻿namespace Invoices.Common;

public class ValidationConstants
{
    // Product
    public const int ProductNameMinLenght = 9;
    public const int ProcuctNameMaxLenght = 30;


    //Address
    public const int AddressStreetNameMinLenght = 10;
    public const int AddressStreetNameMaxLenght = 20;

    public const int AddressCityMinLenght = 5;
    public const int AddressCityMaxLenght = 15;

    public const int AddressCountryMinLenght = 5;
    public const int AddressCountryMaxLenght = 5;


    // Invoice
    public const int InvoiceMinNumber = 1000000000;
    public const int InvoiceMaxNumber = 1500000000;


    // Clienet
    public const int ClientNameMinLenght = 10;
    public const int ClientNameMaxLenght = 25;
    public const int ClientNumberVatMinLenght = 10;
    public const int ClientNumberVatMaxLenght = 15;

}
