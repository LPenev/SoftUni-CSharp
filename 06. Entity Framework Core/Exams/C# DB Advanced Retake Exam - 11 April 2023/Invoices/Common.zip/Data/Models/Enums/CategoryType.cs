﻿namespace Invoices.Data.Models.Enums;

public enum CategoryType
{
    ADR,
    Filters,
    Lights,
    Others,
    Tyres
}
