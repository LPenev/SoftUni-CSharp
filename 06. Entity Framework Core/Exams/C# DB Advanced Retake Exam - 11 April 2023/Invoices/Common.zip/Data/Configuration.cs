﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Invoices;User=demo;Password=Demo1234";
    }
}
