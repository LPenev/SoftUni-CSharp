﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=localhost;Database=ProductShop;User=demo;Password=Demo1234";
    }
}
