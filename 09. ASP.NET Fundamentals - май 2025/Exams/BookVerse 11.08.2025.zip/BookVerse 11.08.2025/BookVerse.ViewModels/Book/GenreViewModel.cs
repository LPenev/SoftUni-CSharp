﻿namespace BookVerse.ViewModels.Book;

public class GenreViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = null;
}

