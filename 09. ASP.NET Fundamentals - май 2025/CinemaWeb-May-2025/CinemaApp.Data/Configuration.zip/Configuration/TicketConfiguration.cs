﻿using CinemaApp.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace CinemaApp.Data.Configuration;

public class TicketConfiguration : IEntityTypeConfiguration<Ticket>
{
    public void Configure(EntityTypeBuilder<Ticket> builder)
    {
        builder
            .HasKey(t => t.Id);

        builder
            .Property(t => t.Price)
            .IsRequired();

        builder
            .HasOne(t => t.Cinema)
            .WithMany(t => t.Tickets)
            .HasForeignKey(t => t.CinemaId);

        builder
            .HasOne(t => t.Movie)
            .WithMany(t => t.Tickets)
            .HasForeignKey(t => t.MovieId);

        builder
            .HasOne(t => t.User)
            .WithMany()
            .HasForeignKey(t => t.UserId);
    }
}

