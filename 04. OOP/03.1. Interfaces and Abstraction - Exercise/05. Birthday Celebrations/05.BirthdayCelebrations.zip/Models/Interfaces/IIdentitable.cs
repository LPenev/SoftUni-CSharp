﻿namespace BorderControl.Models.Intrefaces
{
    public interface IIdentitable
    {
        string Id { get; }
    }
}
