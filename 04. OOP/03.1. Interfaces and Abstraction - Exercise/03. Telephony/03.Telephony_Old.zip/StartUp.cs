﻿using Telephony.Models;
using Telephony.Models.Interfaces;

namespace Telephony
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            string[] telephoneNumberArray = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] webAdressesArray = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            ICallable callable = null;

            foreach (string currentNumber in telephoneNumberArray)
            {
                if (currentNumber.Length == 7)
                {
                    callable = new StationaryPhone();
                }
                else if (currentNumber.Length == 10)
                {
                    callable = new Smartphone();
                }

                try
                {
                    Console.WriteLine(callable.Call(currentNumber));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            IBrowsable browsable;

            foreach (var webAdresses in webAdressesArray)
            {
                browsable = new Smartphone();

                try
                {
                    Console.WriteLine(browsable.Browse(webAdresses));
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
