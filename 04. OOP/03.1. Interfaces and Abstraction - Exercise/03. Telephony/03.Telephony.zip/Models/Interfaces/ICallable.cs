﻿namespace Telephony.Models.Interfaces
{
    public interface ICallable
    {
        public string Call(string number);
    }
}
