﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowsable
    {
        public string Browse(string url);
    }
}
