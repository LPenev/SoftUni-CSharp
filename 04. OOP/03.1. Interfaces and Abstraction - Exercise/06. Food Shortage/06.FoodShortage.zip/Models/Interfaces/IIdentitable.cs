﻿namespace FoodShortage.Models.Interfaces
{
    public interface IIdentitable
    {
        string Id { get; }
    }
}
