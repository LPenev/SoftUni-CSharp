﻿namespace FoodShortage.Models.Interfaces
{
    public interface IBirthable
    {
        string Birthday { get; }
    }
}
