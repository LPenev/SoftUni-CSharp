﻿using Stealer;

Spy spy = new Spy();
string result = spy.AnalyzeAccessModifiers("Stealer.Hacker");
Console.WriteLine(result);
