﻿namespace Vehicles.IO.Interfaces
{
    public interface IWriter
    {
        public void WriteLine(string str);
    }
}
