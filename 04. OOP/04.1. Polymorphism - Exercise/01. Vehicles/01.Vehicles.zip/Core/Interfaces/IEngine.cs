﻿namespace Vehicles.Core.Interfaces
{
    public interface IEngine
    {
        public void Start();
    }
}
