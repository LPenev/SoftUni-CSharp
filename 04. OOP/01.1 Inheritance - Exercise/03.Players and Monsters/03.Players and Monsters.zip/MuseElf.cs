﻿namespace PlayersAndMonsters
{
    public class MuseElf : Elf
    {
        public MuseElf(string usrname, int level) : base(usrname, level)
        {
            
        }
    }
}
