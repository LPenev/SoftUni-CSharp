﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person peter = new("Peter", 20);
            Person george = new("George", 18);
            Person jose = new("Peter", 43);
        }
    }
}
